MEASUREMENT
-----------

Specify a ``CDASH`` measurement and value to be reported for a test.

If set to a name then that name will be reported to ``CDASH`` as a named
measurement with a value of ``1``.  You may also specify a value by
setting ``MEASUREMENT`` to ``measurement=value``.
