VS_WINRT_EXTENSIONS
-------------------

Deprecated.  Use :prop_tgt:`VS_WINRT_COMPONENT` instead.
This property was an experimental partial implementation of that one.
