IMPORT_PREFIX
-------------

What comes before the import library name.

Similar to the target property :prop_tgt:`PREFIX`, but used for import libraries
(typically corresponding to a ``DLL``) instead of regular libraries.  A
target property that can be set to override the prefix (such as ``lib``)
on an import library name.
