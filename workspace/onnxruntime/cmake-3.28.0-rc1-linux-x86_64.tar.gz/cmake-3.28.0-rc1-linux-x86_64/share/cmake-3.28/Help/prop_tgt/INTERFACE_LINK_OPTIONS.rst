INTERFACE_LINK_OPTIONS
----------------------

.. versionadded:: 3.13

.. |property_name| replace:: link options
.. |command_name| replace:: :command:`target_link_options`
.. |PROPERTY_INTERFACE_NAME| replace:: ``INTERFACE_LINK_OPTIONS``
.. |PROPERTY_LINK| replace:: :prop_tgt:`LINK_OPTIONS`
.. include:: INTERFACE_BUILD_PROPERTY.txt
