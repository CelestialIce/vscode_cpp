VS_SCC_PROJECTNAME
------------------

Visual Studio Source Code Control Project.

Can be set to change the visual studio source code control project
name property.
